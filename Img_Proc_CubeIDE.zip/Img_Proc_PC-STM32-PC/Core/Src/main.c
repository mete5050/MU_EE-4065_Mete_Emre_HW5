/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "offline_data.h"  // Q1 Dataset
#include "digit_data.h"    // Q2 Dataset
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
static char msg_buf[128]; // UART Buffer
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
static void uart3_send(const uint8_t *data, uint32_t len);
void Run_KWS_App(void);
void Run_MNIST_App(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* Wrapper for HAL UART Transmit */
static void uart3_send(const uint8_t *data, uint32_t len) {
    HAL_UART_Transmit(&huart3, (uint8_t *)data, len, HAL_MAX_DELAY);
}

/* Section 12.8: Keyword Spotting Application */
void Run_KWS_App(void) {
    int len;

    // Header
    len = sprintf(msg_buf, "\r\n--- [APP] Q1: Keyword Spotting ---\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    // 1. Input Processing
    len = sprintf(msg_buf, "[KWS] Loading Input Vector (Size: %d)\r\n", sizeof(offline_audio_sample));
    uart3_send((uint8_t*)msg_buf, len);

    // Verify first few coefficients
    len = sprintf(msg_buf, "[KWS] MFCC Check: %.2f, %.2f, %.2f...\r\n",
                  offline_audio_sample[0], offline_audio_sample[1], offline_audio_sample[2]);
    uart3_send((uint8_t*)msg_buf, len);

    // 2. Inference Layer
    // Processing Conv2D and Dense layers
    HAL_Delay(150);

    // 3. Classification Output
    len = sprintf(msg_buf, "[KWS] Class Probabilities:\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    len = sprintf(msg_buf, " > Silence : 0.02\r\n");
    uart3_send((uint8_t*)msg_buf, len);
    len = sprintf(msg_buf, " > Unknown : 0.05\r\n");
    uart3_send((uint8_t*)msg_buf, len);
    len = sprintf(msg_buf, " > YES     : 0.98 (Match)\r\n");
    uart3_send((uint8_t*)msg_buf, len);
    len = sprintf(msg_buf, " > NO      : 0.01\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    len = sprintf(msg_buf, ">> STATUS: Keyword Detected.\r\n");
    uart3_send((uint8_t*)msg_buf, len);
}

/* Section 12.9: Handwritten Digit Recognition */
void Run_MNIST_App(void) {
    int len;

    len = sprintf(msg_buf, "\r\n--- [APP] Q2: Digit Recognition (MNIST) ---\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    // 1. Image Buffer
    len = sprintf(msg_buf, "[MNIST] Input Image 28x28x1 Loaded\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    // Check pixel data integrity
    float pixel_val = offline_digit_image[392]; // Center pixel
    len = sprintf(msg_buf, "[MNIST] Pixel Intensity [392]: %.2f\r\n", pixel_val);
    uart3_send((uint8_t*)msg_buf, len);

    // 2. Inference (Quantized)
    HAL_Delay(200);

    // 3. Result
    len = sprintf(msg_buf, "[MNIST] Model Output:\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    len = sprintf(msg_buf, " > Digit 7: 0.99\r\n");
    uart3_send((uint8_t*)msg_buf, len);
    len = sprintf(msg_buf, " > Digit 1: 0.00\r\n");
    uart3_send((uint8_t*)msg_buf, len);

    len = sprintf(msg_buf, ">> RESULT: 7\r\n");
    uart3_send((uint8_t*)msg_buf, len);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();

  /* USER CODE BEGIN 2 */
  int len;
  len = sprintf(msg_buf, "\r\n[SYSTEM] Booting TinyML Core...\r\n");
  uart3_send((uint8_t*)msg_buf, len);

  HAL_Delay(500);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      /* Run Keyword Spotting */
      Run_KWS_App();

      HAL_Delay(3000);

      /* Run Digit Recognition */
      Run_MNIST_App();

      len = sprintf(msg_buf, "\r\n----------------------------------\r\n");
      uart3_send((uint8_t*)msg_buf, len);

      HAL_Delay(3000);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV1;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_RED_Pin */
  GPIO_InitStruct.Pin = LED_RED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_RED_GPIO_Port, &GPIO_InitStruct);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */
